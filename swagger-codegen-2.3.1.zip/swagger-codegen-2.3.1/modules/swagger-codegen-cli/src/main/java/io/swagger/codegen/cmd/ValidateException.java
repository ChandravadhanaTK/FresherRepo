package io.swagger.codegen.cmd;

/**
 * Created by takuro on 2017/05/02.
 */
public class ValidateException extends RuntimeException {
}
