package io.swagger.codegen.auth;

public interface AuthMethod {
    String getType();

    void setType(String type);
}