package io.swagger.codegen.languages.features;

public interface GzipFeatures {
    
    public static final String USE_GZIP_FEATURE = "useGzipFeature";

    public void setUseGzipFeature(boolean useGzipFeature);

}
