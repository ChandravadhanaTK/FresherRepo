package io.swagger.codegen.languages.features;

public interface GzipTestFeatures {

    public static final String USE_GZIP_FEATURE_FOR_TESTS = "useGzipFeatureForTests";

    public void setUseGzipFeatureForTests(boolean useGzipFeatureForTests);

}
