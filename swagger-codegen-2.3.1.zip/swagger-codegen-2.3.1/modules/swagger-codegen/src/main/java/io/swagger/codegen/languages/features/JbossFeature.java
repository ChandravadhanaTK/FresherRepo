package io.swagger.codegen.languages.features;

public interface JbossFeature {

    public static final String GENERATE_JBOSS_DEPLOYMENT_DESCRIPTOR = "generateJbossDeploymentDescriptor";

    public void setGenerateJbossDeploymentDescriptor(boolean generateJbossDeploymentDescriptor);

}
