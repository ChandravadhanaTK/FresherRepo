package io.swagger.codegen.languages.features;

public interface LoggingTestFeatures {
    public static final String USE_LOGGING_FEATURE_FOR_TESTS = "useLoggingFeatureForTests";

    public void setUseLoggingFeatureForTests(boolean useLoggingFeatureForTests);

}
