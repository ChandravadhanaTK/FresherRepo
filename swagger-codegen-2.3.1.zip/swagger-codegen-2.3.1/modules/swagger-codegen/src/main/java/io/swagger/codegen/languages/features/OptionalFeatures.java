package io.swagger.codegen.languages.features;

public interface OptionalFeatures {

    // Language supports generating Optional Types
    String USE_OPTIONAL = "useOptional";

    void setUseOptional(boolean useOptional);

}
