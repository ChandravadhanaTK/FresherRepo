package io.swagger.codegen.languages.features;

public interface SwaggerFeatures {

    public static final String USE_SWAGGER_FEATURE = "useSwaggerFeature";

    public void setUseSwaggerFeature(boolean useSwaggerFeature);

}
