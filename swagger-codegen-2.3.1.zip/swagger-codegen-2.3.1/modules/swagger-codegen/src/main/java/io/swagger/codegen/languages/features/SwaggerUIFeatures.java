package io.swagger.codegen.languages.features;

public interface SwaggerUIFeatures extends CXFFeatures {

    public static final String USE_SWAGGER_UI = "useSwaggerUI";

    public void setUseSwaggerUI(boolean useSwaggerUI);

}
