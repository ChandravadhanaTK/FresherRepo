package io.swagger.codegen.haskellhttpclient;

import org.testng.Assert;
import org.testng.annotations.Test;

public class HaskellHttpClientTest {

    @Test(description = "convert a haskell model with dots")
    public void modelTest() {
        Assert.assertEquals(true, true);
    }
}
